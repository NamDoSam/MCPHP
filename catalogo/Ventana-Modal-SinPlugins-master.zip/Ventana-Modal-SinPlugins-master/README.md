# Ventana modal

Aprenderemos a como hacer una ventana modal sin plugins

### [Da Click Aquí para apoyarme en YouTube](https://www.youtube.com/c/AlexCGDesign?sub_confirmation=1)

### [Tutorial: https://youtu.be/YonqjrU2btI](https://youtu.be/YonqjrU2btI)

![AlexCG Design](https://github.com/AlexCGDesign/Ventana-Modal-SinPlugins/blob/master/Modal/VENTANA%20MODAL.png)

### Hecho por: [AlexCG Design](https://www.youtube.com/c/AlexCGDesign?sub_confirmation=1)

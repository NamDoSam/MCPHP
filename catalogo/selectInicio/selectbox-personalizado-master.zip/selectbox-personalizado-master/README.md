# Como Hacer un Selectbox Personalizado con HTML5, CSS y Javascript Puro
### [Tutorial: https://youtu.be/9zS-bBa4j7k](https://youtu.be/9zS-bBa4j7k)

![Como Hacer un Selectbox Personalizado con HTML5, CSS y Javascript Puro](https://raw.githubusercontent.com/falconmasters/selectbox-personalizado/master/img/thumb.png)

Por: [FalconMasters](http://www.falconmasters.com)